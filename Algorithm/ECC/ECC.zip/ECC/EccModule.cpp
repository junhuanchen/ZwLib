
#include "tommath\tommath.h"

#include <stdint.h>

typedef class ecc
{
	mp_int _Mulx, _Muly, _Tx, _Ty;
	mp_int _AddBSubAx, _AddBSubAy, _AddK, _AddT;
	char Bits[0xFF];

protected:

	mp_int P, A, K;

	void PointAdd(mp_int *Ax, mp_int *Ay, mp_int *Bx, mp_int *By, mp_int *Cx, mp_int *Cy, mp_int *a, mp_int *p)
	{
		mp_sub(Bx, Ax, &_AddBSubAx);
		if (mp_cmp_d(&_AddBSubAx, 0) == MP_LT) mp_add(&_AddBSubAx, p, &_AddBSubAx);
		mp_sub(By, Ay, &_AddBSubAy);
		if (mp_cmp_d(&_AddBSubAy, 0) == MP_LT) mp_add(&_AddBSubAy, p, &_AddBSubAy);
		if (mp_cmp_d(&_AddBSubAx, 0) != MP_EQ)
		{
			fast_mp_invmod(&_AddBSubAx, p, &_AddT);
			mp_mulmod(&_AddBSubAy, &_AddT, p, &_AddK);
		}
		else
		{
			if (mp_cmp_d(&_AddBSubAy, 0) == MP_EQ)
			{
				mp_addmod(Ay, Ay, p, &_AddK), fast_mp_invmod(&_AddK, p, &_AddK);
				mp_sqr(Ax, &_AddT), mp_mul_d(&_AddT, 3, &_AddT), mp_add(&_AddT, a, &_AddT);
				mp_mulmod(&_AddT, &_AddK, p, &_AddK);
			}
			else
			{
				mp_copy(Ax, Cx), mp_copy(Ay, Cy);
				return;
			}
		}
		fast_s_mp_sqr(&_AddK, &_AddT), mp_sub(&_AddT, Ax, &_AddT), mp_submod(&_AddT, Bx, p, Cx);
		mp_sub(Ax, Cx, &_AddT), mp_mul(&_AddT, &_AddK, &_AddT), mp_submod(&_AddT, Ay, p, Cy);
	}

	void PointMul(mp_int *Qx, mp_int *Qy, mp_int *Px, mp_int *Py, mp_int *k, mp_int *a, mp_int *p)
	{
		mp_copy(Px, &_Tx), mp_copy(Py, &_Ty);
		mp_sub_d(k, 1, k), mp_toradix(k, Bits, 2), mp_add_d(k, 1, k);
		mp_copy(Px, Qx), mp_copy(Py, Qy);
		int i = mp_count_bits(k) - 1;
		if (i)
		{
		WHILE:
			if (Bits[i] == '1')
			{
				mp_copy(Qx, &_Mulx), mp_copy(Qy, &_Muly);
				PointAdd(&_Mulx, &_Muly, &_Tx, &_Ty, Qx, Qy, a, p);
			}
			if (0 == --i) return;
			mp_copy(&_Tx, &_Mulx), mp_copy(&_Ty, &_Muly);
			PointAdd(&_Mulx, &_Muly, &_Tx, &_Ty, &_Tx, &_Ty, a, p);
			goto WHILE;
		}
	}

public:

	ecc()
	{
		mp_init(&K);
		mp_init(&A);
		mp_init(&P);
		mp_init(&_AddBSubAx);
		mp_init(&_AddBSubAy);
		mp_init(&_AddK);
		mp_init(&_AddT);
		mp_init(&_Mulx);
		mp_init(&_Muly);
		mp_init(&_Tx);
		mp_init(&_Ty);
	}

	~ecc()
	{
		mp_clear(&K);
		mp_clear(&A);
		mp_clear(&P);
		mp_clear(&_AddBSubAx);
		mp_clear(&_AddBSubAy);
		mp_clear(&_AddK);
		mp_clear(&_AddT);
		mp_clear(&_Mulx);
		mp_clear(&_Muly);
		mp_clear(&_Tx);
		mp_clear(&_Ty);
	}

	void Init(mp_int * k, mp_int * a, mp_int * p)
	{
		mp_copy(k, &K), mp_copy(a, &A), mp_copy(p, &P);
	}

	void Init(int k, int a, int p)
	{
		mp_set_int(&K, k), mp_set_int(&A, a), mp_set_int(&P, p);
	}

}Ecc;

typedef class ecc_encrypt : public Ecc
{
	mp_int R, _Ex, _Ey, _GetT, _Gx, _Gy, _KGx, _KGy;

	void GetBAndG(mp_int *x, mp_int *y, mp_int *b, mp_int *a, mp_int *p)
	{
		// Ep(a,b)�����㷽��: 4 * a^3 + 27 * b^2 �� 0 (mod p)
		// x = 4 * a^3 ע:do-while������_Gx������ʱ����
		mp_expt_d(a, 3, x), mp_mul_d(x, 4, x);
		do
		{
			// b = Prime()
			// GetPrime(b, ARG);
			mp_set_int(b, 1);
			// _GetT = 27 * b^2
			fast_s_mp_sqr(b, &_GetT), mp_mul_d(&_GetT, 27, &_GetT);
			// _GetT = (x + _GetT) mod 5
			mp_add(x, &_GetT, &_GetT), mp_mod(&_GetT, p, &_GetT);
		} while (mp_cmp_d(&_GetT, 0) == MP_EQ);

		// ���ѡȡX���뷽��: y^2 = x^3 + a * x + b, �Ӷ��õ� Y
		// x = [0, p^(1.0/3.0)], TmpT = x^3, x = a * x
		mp_set_int(x, 1); // С�� p �ĸ�����
		mp_expt_d(x, 3, &_GetT), mp_mul(a, x, x);
		// TmpT = TmpT + x + b
		mp_add(&_GetT, x, &_GetT), mp_add(&_GetT, b, &_GetT);
		// y = sqrt(TmpT)
		mp_sqrt(&_GetT, y);
	}

	public:

	ecc_encrypt()
	{
		mp_init(&R);
		mp_init(&_Ex);
		mp_init(&_Ey);
		mp_init(&_GetT);
		mp_init(&_Gx);
		mp_init(&_Gy);
		mp_init(&_KGx);
		mp_init(&_KGy);
	}

	~ecc_encrypt()
	{
		mp_clear(&R);
		mp_clear(&_Ex);
		mp_clear(&_Ey);
		mp_clear(&_GetT);
		mp_clear(&_Gx);
		mp_clear(&_Gy);
		mp_clear(&_KGx);
		mp_clear(&_KGy);
	}

	void Init(int k, int a, int p)
	{
		Ecc::Init(k, a, p);
		mp_int B;
		mp_init(&B);
		GetBAndG(&_Gx, &_Gy, &B, &A, &P);
		PointMul(&_KGx, &_KGy, &_Gx, &_Gy, &K, &A, &P);
		mp_clear(&B);
	}

	void Encrypt(mp_int * _Mx, mp_int * _My, mp_int * _C1x, mp_int * _C1y, mp_int * _C2x, mp_int * _C2y)
	{
		// 4������һ���������r��r < n��
		mp_init_set_int(&R, (rand() % mp_get_int(&K)) + 1);
		// C2(x,y) = r*G(x,y)
		PointMul(_C2x, _C2y, &_Gx, &_Gy, &R, &A, &P);
		// 5���û�B�����C1(x,y) = M(x,y) + r*K(x,y), C2(x,y) = r*G(x,y)
		// tmp(x,y) = r*K(x,y) ע: K(x,y) = k*G(x,y)
		PointMul(&_Ex, &_Ey, &_KGx, &_KGy, &R, &A, &P);
		// C1(x,y) = M(x,y) + tmp(x,y)
		PointAdd(_Mx, _My, &_Ex, &_Ey, _C1x, _C1y, &A, &P);
	}
}EccEncrypt;

typedef class ecc_decrypt : public Ecc
{
	mp_int _Dx, _Dy;

public:

	void Decrypt(mp_int * _C1x, mp_int * _C1y, mp_int * _C2x, mp_int * _C2y, mp_int * _Mx, mp_int * _My)
	{
		// tmp(x,y) = k*C2(x,y)
		PointMul(&_Dx, &_Dy, _C2x, _C2y, &K, &A, &P);
		// tmp(x,y) = - tmp(x,y) ע:P(x,y)�ĸ�Ԫ��-P(x,-y)
		mp_neg(&_Dy, &_Dy);
		// M(x,y) = C1(x,y) + tmp(x,y)
		PointAdd(_C1x, _C1y, &_Dx, &_Dy, _Mx, _My, &A, &P);
		// ʵ��ԭ��ע: M(x,y) = C1(x,y) - r*K(x,y), r*K(x,y) == k*C2(x,y)
	}

	ecc_decrypt()
	{
		mp_init(&_Dx);
		mp_init(&_Dy);
	}

	~ecc_decrypt()
	{
		mp_clear(&_Dx);
		mp_clear(&_Dy);
	}

}EccDecrypt;


#include <assert.h>
#include <Windows.h>

int main()
{
	int start = GetTickCount64();
	mp_int _C1x, _C1y, _C2x, _C2y, _Mx, _My;		// ��������ܹ����б任�ı���
	mp_init(&_Mx), mp_init(&_My), mp_init(&_C1x), mp_init(&_C1y), mp_init(&_C2x), mp_init(&_C2y);

	EccEncrypt En;
	En.Init(127, 1, 127);

	EccDecrypt De;
	De.Init(127, 1, 127);

	for (int i = 0; i != 127; i++)
	{
		mp_set_int(&_Mx, i), mp_set_int(&_My, i);

		En.Encrypt(&_Mx, &_My, &_C1x, &_C1y, &_C2x, &_C2y);

		mp_set_int(&_Mx, 0), mp_set_int(&_My, 0);

		De.Decrypt(&_C1x, &_C1y, &_C2x, &_C2y, &_Mx, &_My);

		int Mx = mp_get_int(&_Mx), My = mp_get_int(&_My);

		// assert(Mx == My);

		printf("i:%d-M(%d, %d)\n", i, Mx, My);
	}

	int end = GetTickCount64();
	printf("result:%d\n", end - start);
	system("pause");
}